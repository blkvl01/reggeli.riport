# HGL Reggeli Riport Dashboard

Automatikus reggeli riport dashboard a HGL Ecommerce csapat számára.

## 📊 Dashboard elérése

🔗 **https://hgllog.github.io/reggeli-riport/reggeli_riport.html**

(vagy saját domain: `riport.hgl.hu`)

## ⏰ Frissítés

Automatikusan minden nap reggel 6:00-kor (GitHub Actions)

## 🔧 Manuális futtatás

1. Menj a [Actions](../../actions) fülre
2. Válaszd ki: "Reggeli Riport Dashboard"
3. Kattints: "Run workflow"

## 📁 Fájlok

- `reggeli_riport.ps1` - PowerShell script (SharePoint adatok)
- `.github/workflows/daily-dashboard.yml` - GitHub Actions automatizálás
- `reggeli_riport.html` - Generált dashboard (auto-deploy)

## 📝 Verzió

SharePoint Direct Access v1.0
